---
layout: page
title: About
permalink: /about/
---

This site is a personal knowledge base — a collection of things I’ve learned over time.  
It’s here so I can remember them, and maybe they’ll help someone else too.
