---
layout: home
title: "Things I Know"
---

Welcome to my collection of notes, lessons, and discoveries.  
Everything here is something I’ve learned, tested, or found useful.  
Click on a title to read more.
