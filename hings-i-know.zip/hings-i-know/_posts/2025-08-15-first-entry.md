---
title: "My First Knowledge Entry"
date: 2025-08-15
tags: [example, welcome]
---

This is my very first entry in **Things I Know**.  
From now on, I’ll add notes, lessons, and ideas here.

**Tip:** Every post filename must start with `YYYY-MM-DD-` format.
